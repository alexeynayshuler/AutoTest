#!/bin/bash

LOGS_DIR="/disk/qat_logs"

mkdir $LOGS_DIR/ 2> /dev/null
rm $LOGS_DIR/* 2> /dev/null

INDEX=0

killall -9 qat_test_suite.bash 2> /dev/null
killall -9 cpa_sample_code 2> /dev/null
sleep 5s

while [ 1 ]; do
    let INDEX=$INDEX+1
    ./qat_test_suite.bash performance 2>&1 > $LOGS_DIR/test$INDEX.log & disown

    trap "echo; echo Quitting...;killall -9 qat_test_suite.bash 2> /dev/null; killall -9 cpa_sample_code 2> /dev/null;sleep 2s; exit" INT

    echo "Running iteration #$INDEX"    
    
    for i in `seq 1 60`; do
        echo -n "."
        sleep 30s
        if test -e $(pgrep qat_test_suite); then
            echo "Test stopped before the expected time, continuing to next iteration"
            break
        fi
    done

    echo

    last_line=$(tail -n 1 $LOGS_DIR/test$INDEX.log)

    if [[ "$last_line" == "Test finished successfully"* ]]; then
        echo "The test was finished successfuly!!!"
    else
        echo "The test FAILED"
    fi

    echo "Killing qat_test_suite, cpa_sample_code if exist"
    killall -9 qat_test_suite.bash 2> /dev/null
    killall -9 cpa_sample_code 2> /dev/null
    echo "Waiting 5 seconds before next iteration"
    sleep 5s
    echo
done
