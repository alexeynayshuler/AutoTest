#!/bin/bash

qat_tests_output=test_suite_output.txt
num_of_endpoints=$(lspci | grep 37c8 | wc -l)
redirect_to_file=1

####################
#   Test Runner    #
####################
function run_test()
{
  echo "Run of $1 started at: "$(date)
  if [ $redirect_to_file -eq 1 ]; then
    ./$1 $2 $3 $4 >> $qat_tests_output
  else
    ./$1 $2 $3 $4
  fi

  exit_code=$?
  echo "Run of $1 ended at: "$(date)" with exit code $exit_code"
}


#num_of_endpoints=$1
#if [ -z "$num_of_endpoints" ]
#then
#echo "Usage: $0 num-of-qat-endpoints (LBG-E=0 LBG-M=1 LBG-L=2)"
#exit 1
#fi

performance_mode=$1

# Cleanup
##########
rm -f /etc/dh895xcc_dev0.conf   || true
rm -f /etc/dh895xcc_dev1.conf   || true
rm -f /etc/c6xx_dev0.conf       || true
rm -f /etc/c6xx_dev1.conf       || true
rm -f /etc/c6xx_dev2.conf       || true
rm -f /etc/c6xx_dev3.conf       || true
rm -f /etc/c6xx_dev4.conf       || true
rm -f /etc/c6xx_dev5.conf       || true
rm -f /lib/firmware/qat_895xcc* || true
rm -f /lib/firmware/qat_c62x*   || true
rm -f /etc/init.d/qat_service   || true
rm -f /usr/sbin/adf_ctl         || true
rm -f /disk/adf_ctl             || true
rmmod usdm_drv.ko     > /dev/null 2>&1 || true
rmmod qat_dh895xcc.ko > /dev/null 2>&1 || true
rmmod qat_c62x.ko     > /dev/null 2>&1 || true
rmmod intel_qat.ko    > /dev/null 2>&1 || true

# Setup
#########
mkdir /lib/firmware/qat_fw                       > /dev/null 2>&1
install -D -m 640 qat_c62x.bin /lib/firmware     > /dev/null 2>&1
install -D -m 640 qat_c62x_a0.bin /lib/firmware  > /dev/null 2>&1
install -D -m 640 qat_c62x_mmp.bin /lib/firmware > /dev/null 2>&1

install -D -m 640 c6xx_dev0.conf /etc/c6xx_dev0.conf > /dev/null 2>&1
install -D -m 640 c6xx_dev0.conf /etc/c6xx_dev1.conf > /dev/null 2>&1
install -D -m 640 c6xx_dev0.conf /etc/c6xx_dev2.conf > /dev/null 2>&1

install -D -m 750 qat_service_modified /etc/init.d/qat_service > /dev/null 2>&1
install -D -m 750 adf_ctl_static /disk/adf_ctl                 > /dev/null 2>&1
mount -t debugfs debugfs /sys/kernel/debug                     > /dev/null 2>&1

insmod intel_qat.ko > /dev/null 2>&1
insmod qat_c62x.ko  > /dev/null 2>&1
insmod usdm_drv.ko  > /dev/null 2>&1

/sbin/depmod -a

echo
echo "Loading QAT Drivers"
echo "-------------------"
service qat_service start
service qat_service status > $qat_tests_output
endpoints=$(grep "up" $qat_tests_output | wc -l)
down_endpoints=$(grep "down" $qat_tests_output | wc -l)
if [[ "$down_endpoints" != "0" ]]
then
echo "QAT endpoints down - test FAILED!!!!"
exit 1
fi
if [[ "$endpoints" != "$num_of_endpoints" ]]
then
echo "Wrong number of QAT endpoints - test FAILED!!!!"
exit 1
fi

echo

####################
# Functional tests #
####################
echo "Running Functional tests"
echo "------------------------"
> $qat_tests_output
run_test tests/functional/asym/prime_sample
run_test tests/functional/asym/dh_sample
run_test tests/functional/sym/sym_dp_sample
run_test tests/functional/sym/algchaining_sample
run_test tests/functional/sym/hash_sample
run_test tests/functional/sym/gcm_sample
run_test tests/functional/sym/ipsec_sample
run_test tests/functional/sym/ccm_sample
run_test tests/functional/sym/cipher_sample
run_test tests/functional/sym/ssl_sample
echo "Functional tests done"

############################
# Functional Tests results #
############################
expected_number_of_tests=10
functional=$(grep "Sample code ran successfully" $qat_tests_output | wc -l)

if [[ "$functional" == "$expected_number_of_tests" ]]
then
echo "Functional tests OK"
else
echo "Functional tests FAILED!!!!"
exit 1
fi

######################
# Sign Of Life tests #
######################
if [[ "$performance_mode" == "performance" ]]
then
echo
echo "Running Sign Of Life tests (performance mode)"
echo "---------------------------------------------"
redirect_to_file=0
run_test tests/performance/cpa_sample_code
redirect_to_file=1
echo "Sign Of Life test (performance mode) done"
else
echo
echo "Running Sign Of Life tests"
echo "--------------------------"
run_test tests/performance/cpa_sample_code signOfLife=1
echo "Sign Of Life test done"
fi

##############################
# Sign Of Life Tests results #
##############################
if [[ "$performance_mode" == "performance" ]]
then
echo "Sign of life (performance mode) - skip verification step"
else
expected_number_of_responses=96
let "expected_response_count=120 * $num_of_endpoints"
signOfLife=$(grep "Total Responses       $expected_response_count" $qat_tests_output | wc -l)

if [[ "$signOfLife" == "$expected_number_of_responses" ]]
then
echo "Sign of life test OK"
else
echo "Sign of life test FAILED!!!!"
exit 1
fi
fi

###########
# Summary #
###########
echo
echo "Summary"
echo "-------"
if [[ "$endpoints" == "1" ]]
then
echo "LBG-E card is identified "
elif [[ "$endpoints" == "2" ]]
then
echo "LBG-M card is identified"
elif [[ "$endpoints" == "3" ]]
then
echo "LBG-L card is identified"
fi
echo "Test finished successfully!!!"

# rm -f $qat_tests_output
exit 0
